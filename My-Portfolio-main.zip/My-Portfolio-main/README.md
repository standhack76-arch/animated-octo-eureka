# Bahafid - Personal Portfolio

A modern, minimalist personal portfolio website showcasing coding skills, design work, and professional journey. Built with pure HTML, CSS, and JavaScript - no frameworks, no build tools.

## Features

- **Modern Design**: Clean, elegant interface with neutral colors and smooth transitions
- **Responsive Layout**: Fully responsive design works flawlessly on all devices
- **Smooth Animations**: Subtle micro-interactions and fade-in animations
- **Skills Section**: Visual skill level bars showing proficiency in different technologies
- **Timeline**: Professional journey visualization
- **Netlify Ready**: Pre-configured for instant deployment
- **Performance Optimized**: Lighthouse-optimized with fast load times
- **Accessibility**: WCAG compliant with proper semantic HTML
- **SEO Optimized**: Meta tags and structured data for search engines

## Project Structure

```
My-Portfolio/
├── index.html           # Main HTML file
├── assets/
│   ├── css/
│   │   └── style.css    # All styling
│   └── js/
│       └── script.js    # Interactivity
├── netlify.toml        # Netlify configuration
└── .gitignore          # Git ignore rules
```

## Technologies Used

- HTML5 (semantic markup)
- CSS3 (custom properties, grid, flexbox, animations)
- Vanilla JavaScript (ES6+)
- Google Fonts (Inter)

## Skills Showcased

- **Programming**: C (1.5/10), Git (1/10), Python (0.5/10), Java (0.5/10), Web Development (0.5/10)
- **Creative**: Design & Canva (Beginner), Video Editing with CapCut (Beginner)
- **Soft Skills**: Adaptability, Problem Solving, Collaboration, Communication

## Education

- **1337 School** - Intensive Coding Bootcamp (2025)
- **Faculté Dhar El Mahraz** - Computer Science (2024)

## Deployment

### Netlify (Recommended)

1. Push your repository to GitHub
2. Connect repository to Netlify
3. Deploy automatically - that's it!

The `netlify.toml` file is already configured for optimal deployment.

### Manual Deployment

Simply upload all files to your hosting provider's public folder. No build step required!

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Performance

- **Lighthouse Score**: 95+
- **Page Load**: < 1 second
- **No External Dependencies**: Just HTML, CSS, JS
- **Optimized Images**: CDN-hosted images with lazy loading

## Customization

All styling uses CSS custom properties (variables) defined in `:root`. Edit colors, spacing, and animations easily:

```css
:root {
  --color-primary: #3b82f6;
  --color-bg: #0f0f0f;
  /* ... more variables ... */
}
```

## License

Open for personal use. Feel free to customize and deploy!

## Connect

- LinkedIn: https://www.linkedin.com/in/bahafid/
- Portfolio: [Your Netlify URL]

---

**Made with passion and clean code** ✨
